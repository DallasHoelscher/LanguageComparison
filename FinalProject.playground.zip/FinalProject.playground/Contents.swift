//: Playground - noun: a place where people can play

import UIKit

//Optionals
var x: Int? = 7

func testGuard() {
    guard let x = x else {
        return
    }
    //If x wasn't nil, notice there is no need to unwrap x
    print(x)
}


testGuard()

class Pet {
    var type: String
    init (type: String) {
        self.type = type
    }
    
    deinit {
        print("Going away now")
    }
}

var myDog:Pet? = Pet(type: "Dog")
print(myDog!.type)

weak var otherDog = myDog

myDog = nil


struct XY {
    var x = 9
    var y = 15
    
    var yMinusX: Int {
        return y - x   //Computed property
    }
}

var xy = XY()
var this = xy.yMinusX //Returns 6

xy.x = 14
this = xy.yMinusX //Returns 1


protocol FullyNamed {
    var fullName: String { get }
}

struct Person: FullyNamed {
    var fullName: String
}
let john = Person(fullName: "John Appleseed")



var doubleOne = 0.0

var firstInt = 7
var secondInt = 7

if firstInt == secondInt {
    print("true")
}
let newDog = Pet(type: "Dog")
if myDog === otherDog {
    print("Dogs are same")
}
if myDog !== newDog {
    print("Dogs are not the same")
}


let names = ["Chris", "Alex", "Ewa", "Barry", "Daniella"]

let reversedNames = names.sorted(by: >)
